package com.roilen.code.easyjava.lesson25.example3;

public class Person {
    private String name;
    private int personId;
    private String address;

    public Person(String name, int personId, String address) {
        this.name = name;
        this.personId = personId;
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPersonId() {
        return personId;
    }

    public void setPersonId(int personId) {
        this.personId = personId;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
