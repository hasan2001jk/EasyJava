package games.rgb.easyjava;

public class Arrays {
    public static void main(String[] args){
        int[] randomNumbers = new int[5];
        randomNumbers[0] = 13;
        randomNumbers[1] = 07;
        randomNumbers[2] = 17;
        randomNumbers[3] = 19;
        randomNumbers[4] = 10;

        char[] rgb = {'R', 'G', 'B'};
        char rgb2[] = new char[3];

        int[][][][] fourDimensions = new int[5][][][];

        fourDimensions[0][0][0] = new int[5];
        fourDimensions[0][0][1] = new int[25];
        fourDimensions[0][0][2] = new int[3];
        fourDimensions[0][0][3] = new int[10];

    }
}
