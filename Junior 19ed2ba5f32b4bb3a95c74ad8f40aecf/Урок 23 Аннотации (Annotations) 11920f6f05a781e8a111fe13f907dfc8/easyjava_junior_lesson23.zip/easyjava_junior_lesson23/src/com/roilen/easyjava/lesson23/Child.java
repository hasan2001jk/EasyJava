package com.roilen.easyjava.lesson23;

public class Child extends Parent{
    @Override
    public void parentMethod() {
    }
}
