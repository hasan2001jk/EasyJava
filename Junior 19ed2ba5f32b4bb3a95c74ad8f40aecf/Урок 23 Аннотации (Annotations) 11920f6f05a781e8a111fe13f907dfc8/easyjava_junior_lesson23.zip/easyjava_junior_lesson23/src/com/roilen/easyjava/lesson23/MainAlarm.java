package com.roilen.easyjava.lesson23;

//@Alarms({
//        @Alarm("10:00"),
//        @Alarm("12:00"),
//        @Alarm("14:00")
//})

@Alarm("10:00")
@Alarm("12:00")
@Alarm("14:00")
public class MainAlarm {
    public static void main(String[] args) {
        Alarms alarms = MainAlarm.class.getAnnotation(Alarms.class);
        for (Alarm alarm : alarms.value()) {
            System.out.println(alarm.value());
        }
    }
}
