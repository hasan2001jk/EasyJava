package com.roilen.easyjava.lesson23;

import java.lang.annotation.Repeatable;

@Repeatable(Alarms.class)
public @interface Alarm {
    String value();
}
