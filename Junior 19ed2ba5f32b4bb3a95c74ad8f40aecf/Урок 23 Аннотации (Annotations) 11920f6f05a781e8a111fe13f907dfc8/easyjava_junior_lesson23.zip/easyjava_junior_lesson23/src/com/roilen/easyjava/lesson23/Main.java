package com.roilen.easyjava.lesson23;

import java.lang.annotation.Annotation;
import java.lang.reflect.Array;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Parent parent = new Parent();
        parent.deprecatedMethod();

        processTwoNumbers(1, 2, (a, b) -> a+b);

        Child child = new Child();
        System.out.println("Parent Annotations: ");
        for (Annotation annotation: parent.getClass().getAnnotations()) {
            System.out.println(annotation);
        }
        System.out.println("Child Annotations: ");
        for (Annotation annotation: child.getClass().getAnnotations()) {
            System.out.println(annotation);
        }

    }

    public static int processTwoNumbers(int a, int b, MyFuncInterface function) {
        return a+b;
    }

    @SuppressWarnings("unused")
    public static void unUsedMethod() {

    }

    public static void varArgsMethod(String... strings){
        System.out.println(Arrays.toString(strings));
    }

    @SafeVarargs
    public static <T> void unSafeVarArgsMethod(T... strings){
        System.out.println(Arrays.toString(strings));
    }



}