package com.roilen.easyjava.lesson23;

@FunctionalInterface
public interface MyFuncInterface {
    int field = 0;

    default int intGetField() {
        return field;
    }
    int theOneAndOnlyAbstractMethod(int a, int b);
//    int theSecondMethod();
}
