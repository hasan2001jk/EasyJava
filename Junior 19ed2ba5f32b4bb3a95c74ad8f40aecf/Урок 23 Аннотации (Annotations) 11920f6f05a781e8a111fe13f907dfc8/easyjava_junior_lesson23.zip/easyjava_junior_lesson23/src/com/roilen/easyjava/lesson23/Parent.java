package com.roilen.easyjava.lesson23;

@InheritedAnnotation
@NonInheritedAnnotation
public class Parent {
    public void parentMethod() {

    }

    @Deprecated
    public void deprecatedMethod(){

    }
}
