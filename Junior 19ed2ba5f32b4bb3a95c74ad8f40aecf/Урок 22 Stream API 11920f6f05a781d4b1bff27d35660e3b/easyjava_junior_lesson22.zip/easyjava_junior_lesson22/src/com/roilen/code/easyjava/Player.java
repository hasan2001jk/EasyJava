package com.roilen.code.easyjava;

public class Player {
    public static int playerCount(int i) {
        return 1;
    }

    public boolean isActive(Player p) {
        return true;
    }
}
