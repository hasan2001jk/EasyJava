package com.roilen.code.easyjava;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Main {

    public static void main(String[] args) {
//        List.of(1,2,3,4,5).forEach(Player::playerCount);
//        List.of(1,2,3,4,5).forEach(i -> System.out.println(i));

        Player player = new Player();
        //

//        Stream.of(1,2,3,4,5,6,7,8,9).filter(i -> i < 5)
//                .forEach(System.out::println);

//        Stream.of(1,2,3,4,5,6,7,8,9).map(i -> i + 1)
//                .forEach(System.out::println);

        List<List<String>> list = Arrays.asList(Arrays.asList("Test1"), Arrays.asList("Test2"));
        System.out.println(list);
        list.stream().flatMap(Collection::stream).forEach(System.out::println);

        Stream.of(1,2,3,4,5,6,7,8,9).forEach(System.out::println);

        //павильно
        List.of(1,2,3,4,5,6,7,8,9).forEach(System.out::println);
        //не правильно
        List.of(1,2,3,4,5,6,7,8,9).stream().forEach(System.out::println);

        List<Integer> listIntegers = Stream.of(1,2,3,4,5,6,7).collect(Collectors.toList());

        String[] words = {"hello", "world", "java", "test"};

        String string = Arrays.stream(words).collect(Collectors.joining(" "));
        System.out.println(string);

        Optional<Integer> max = Stream.of(1,2,3,4,5,6,7,8,9)
                .reduce(Math::max);


        System.out.println(max.get());
    }
}
