package com.roilen.code.easyjava.lesson24;

public class MainClassExample {
    public static void main(String[] args) {
        ClassForReflection classForReflection = new ClassForReflection();
        Class<? extends ClassForReflection> classFor = classForReflection.getClass();
    }
}
