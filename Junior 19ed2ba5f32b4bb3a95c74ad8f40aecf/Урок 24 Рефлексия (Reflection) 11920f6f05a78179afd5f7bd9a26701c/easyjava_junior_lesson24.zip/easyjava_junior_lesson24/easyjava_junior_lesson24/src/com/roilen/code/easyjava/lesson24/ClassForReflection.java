package com.roilen.code.easyjava.lesson24;

public class ClassForReflection {
    private String somePrivateName = "someName";
}
