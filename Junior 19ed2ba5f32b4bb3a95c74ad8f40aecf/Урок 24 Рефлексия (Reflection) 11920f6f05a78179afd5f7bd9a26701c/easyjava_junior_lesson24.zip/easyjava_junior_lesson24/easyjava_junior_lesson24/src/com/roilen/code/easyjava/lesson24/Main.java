package com.roilen.code.easyjava.lesson24;

import java.lang.reflect.Field;

public class Main {
    public static void main(String[] args) {
        ClassForReflection classForReflection = new ClassForReflection();
        try {
            Field field = classForReflection.getClass()
                    .getDeclaredField("somePrivateName");
            field.setAccessible(true);
            String name = (String) field.get(classForReflection);
            System.out.println(name);
        } catch (NoSuchFieldException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }



    }
}